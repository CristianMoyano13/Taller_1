package Dominio;

public class Producto {
	private String nombre;
	private int precio;
	private int unidades;
	/**
	 * Product
	 * @param nombre
	 * Product name
	 * @param precio
	 * Product price
	 * @param unidades
	 * Product stock
	 */
	public Producto(String nombre, int precio, int unidades) {
		this.nombre = nombre;
		this.precio = precio;
		this.unidades = unidades;
	}
	/**
	 * Returns the product name
	 * @return
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * Sets a new name for the product
	 * @param nombre
	 * Product new name
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * Returns the product price
	 * @return
	 */
	public int getPrecio() {
		return precio;
	}
	/**
	 * Sets a new price for the product
	 * @param precio
	 * Product new price
	 */
	public void setPrecio(int precio) {
		this.precio = precio;
	}
	/**
	 * Returns the product stock
	 * @return
	 */
	public int getUnidades() {
		return unidades;
	}
	/**
	 * Sets a new stock for the product
	 * @param unidades
	 * Product new stock
	 */
	public void setUnidades(int unidades) {
		this.unidades = unidades;
	}
	
	
	
	
}
