package Dominio;

public class Cliente {
	private String nombre;
	private String contrase�a;
	private int saldo;
	private String correo;
	/**
	 * Client
	 * @param nombre
	 * Client's name
	 * @param contrase�a
	 * Client's password
	 * @param saldo
	 * Client's balance
	 * @param correo
	 * Client's e-mail address
	 */
	public Cliente(String nombre, String contrase�a, int saldo, String correo) {
		this.nombre = nombre;
		this.contrase�a = contrase�a;
		this.saldo = saldo;
		this.correo = correo;
	}
	/**
	 * Returns the client's name
	 * @return
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * Sets a new name for the client
	 * @param nombre
	 * Client's new name
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * Returns the client's password
	 * @return
	 */
	public String getContrase�a() {
		return contrase�a;
	}
	/**
	 * Sets a new password for the client
	 * @param contrase�a
	 * Client's new password
	 */
	public void setContrase�a(String contrase�a) {
		this.contrase�a = contrase�a;
	}
	/**
	 * Returns the client's balance
	 * @return
	 */
	public int getSaldo() {
		return saldo;
	}
	/**
	 * Sets a new balance for the client
	 * @param saldo
	 * Client's new balance
	 */
	public void setSaldo(int saldo) {
		this.saldo = saldo;
	}
	/**
	 * Returns the client's e-mail address
	 * @return
	 */
	public String getCorreo() {
		return correo;
	}
	/**
	 * Sets a new e-mail address for the client
	 * @param correo
	 * Client's new e-mail address
	 */
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	
	
	
}
