package Dominio;

public class Venta {
	private String nombre;
	private int cantidadVentas;
	/**
	 * Sale record
	 * @param nombre
	 * Sale product name
	 * @param cantidadVentas
	 * Sold product stock
	 */
	public Venta(String nombre, int cantidadVentas) {
		this.nombre = nombre;
		this.cantidadVentas = cantidadVentas;
	}
	/**
	 * Returns the sale product name
	 * @return
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * Sets a new product name for the sale
	 * @param nombre
	 * New sale product name
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * Returns the sale product stock
	 * @return
	 */
	public int getCantidadVentas() {
		return cantidadVentas;
	}
	/**
	 * Sets a new product stock for the sale
	 * @param cantidadVentas
	 * New sale product stock
	 */
	public void setCantidadVentas(int cantidadVentas) {
		this.cantidadVentas = cantidadVentas;
	}
}
