package L�gica;

import java.io.*;
import java.util.Scanner;

import Dominio.Cliente;
import Dominio.Producto;
import Dominio.Venta;

public class App {
	static ListaClientes listaClientes;
	static ListaProductos listaProductos;
	static ListaVentas listaVentas;
	
	static int cont = 0;
	static int totalPago = 0;
	static String [] nombreCompras = new String [65536];
	static int [] cantCompras = new int [65536];

	static String clienteActual;
	private static Scanner sc;
	public static void main(String[] args) throws NumberFormatException, IOException {
		
		listaClientes = new ListaClientes(1000);
		listaProductos = new ListaProductos(1000);
		listaVentas = new ListaVentas(1000);
		
		Carga_Clientes();
		Carga_Productos();
		Carga_Ventas();
		iniciar_sesion();
		Guardar_Clientes();
		Guardar_Productos();
		Guardar_Ventas();
	}
	/**
	 * Adds a client to the list of clients
	 * @param nombre
	 * Client's name
	 * @param password
	 * Client's password
	 * @param saldo
	 * Client's balance
	 * @param correo
	 * Client's e-mail address
	 * @return
	 */
	public static boolean agregarCliente(String nombre,String password,int saldo,String correo) {
		Cliente c = new Cliente(nombre,password,saldo,correo);
		boolean ingreso = listaClientes.insertarCliente(c);
		return ingreso;
	}
	/**
	 * Adds a product to the list of products
	 * @param nombreProducto
	 * Product name
	 * @param precio
	 * Product price
	 * @param unidades
	 * Product stock
	 * @return
	 */
	public static boolean agregarProducto(String nombreProducto,int precio,int unidades) {
		Producto p = new Producto(nombreProducto, precio, unidades);
		boolean ingreso = listaProductos.insertarProducto(p);
		return ingreso;
	}
	/**
	 * Adds a sale to the list of sales
	 * @param nombreProducto
	 * Sold product name
	 * @param cantidad
	 * Sold product stock
	 * @return
	 */
	public static boolean agregarVenta(String nombreProducto, int cantidad) {
		Venta v = new Venta(nombreProducto, cantidad);
		boolean ingreso = listaVentas.insertarVenta(v);
		return ingreso;
	}
	/**
	 * Reads the file "Clientes.txt", adding the clients and their personal info. to system
	 * @throws NumberFormatException
	 * @throws IOException
	 */
	public static void Carga_Clientes() throws NumberFormatException, IOException{
		Scanner reader = new Scanner(new File("Clientes.txt"));
        while(reader.hasNextLine()){
            String linea = reader.nextLine();
            String [] partes = linea.split(",");
            String nombre = partes[0];
            String contrase�a = partes[1];
            int saldo = Integer.parseInt(partes[2]);
            String correo = partes[3];
            agregarCliente(nombre,contrase�a,saldo,correo);
        }
        reader.close();
	}
	/**
	 * Reads the file "Productos.txt", adding the products and their stock and price to system
	 * @throws NumberFormatException
	 * @throws IOException
	 */
	private static void Carga_Productos() throws NumberFormatException, IOException{
		Scanner reader = new Scanner(new File("Productos.txt"));
        while(reader.hasNextLine()){
            String linea = reader.nextLine();
            String [] partes = linea.split(", ");
            String nombreProducto = partes[0];
            int precio = Integer.parseInt(partes[1]);
            int unidades = Integer.parseInt(partes[2]);
            agregarProducto(nombreProducto, precio, unidades);
        }
        reader.close();
	}
	/**
	 * Reads the file "Ventas.txt", adding the sales data to system
	 * @throws NumberFormatException
	 * @throws IOException
	 */
	private static void Carga_Ventas()throws NumberFormatException, IOException{
		Scanner reader = new Scanner(new File("Ventas.txt"));
        while(reader.hasNextLine()){
            String linea = reader.nextLine();
            String [] partes = linea.split(",");
            String nombreProducto = partes[0];
            int cantidad = Integer.parseInt(partes[1]);
            agregarVenta(nombreProducto, cantidad);
        }
        reader.close();
	} 
	/**
	 * Opens log in menu
	 * Leads to the rest of programmes depending on the entered user
	 */
	private static void iniciar_sesion() {
		boolean llave = true;
		while(llave) {
			System.out.println("INICIAR SESI�N");
			System.out.println("Escriba su nombre de usuario: ");
			System.out.println("Para finalizar el programa, introduzca 0");
			sc = new Scanner(System.in);
			String nombre = sc.nextLine();
			int posicion=clasificar_nombre(nombre);
			if((nombre).equals("0")) {
				llave=false;
				System.out.println("Se ha finalizado la operaci�n");
			}
			else if (posicion==-1) {
				System.out.println("Escriba su contrase�a:");
				String contrase�a = sc.nextLine();
				if((contrase�a).equals("NYAXIO")) {
					menu_admin();
				}
				else{
					System.out.println("ERROR-Contrase�a inv�lida");
				}
			}
			else if (posicion>=0) {
				clienteActual = nombre;
				System.out.println("Escriba su contrase�a");
				String contrase�a = sc.nextLine();
				if((contrase�a).equals(listaClientes.getClienteI(posicion).getContrase�a())) {
					menu_cliente();
				}
				else{
					System.out.println("ERROR-Contrase�a inv�lida");
				}
			}
			else{
				System.out.println("Usuario no existe");
				System.out.println("�Desea crear un nuevo usuario?");
				System.out.println("Y/N");
				String clave = sc.nextLine();
				if((clave).equals("y")||(clave).equals("Y")) {
					nuevo_usuario(nombre);
				}
				else if (!(clave).equals("n")&&!(clave).equals("N")){
					System.out.println("ERROR-COMANDO NO RECONOCIDO");
				}
				System.out.println("Volviendo al principio de la operaci�n");
			}
		}
	}
	/**
	 * Recieves a name and searches for its index in the clients list if exists
	 * @param nombre
	 * Wanted name in the list
	 * @return
	 */
	public static int clasificar_nombre(String nombre) {
		if(nombre.equals("ADMIN")) {
			return -1;
		}
		for(int i=0;i<listaClientes.getCont();i++) {
			if(nombre.equals(listaClientes.getClienteI(i).getNombre())) {
				return i;
			}
		}
		return -2;
	}
	/**
	 * Registers a new client, with its password, empty balance and e-mail address
	 * @param nombre
	 * Entered client's name
	 */
	public static void nuevo_usuario(String nombre){
		sc = new Scanner(System.in);
		System.out.println("NOMBRE: "+nombre);
		System.out.println("Por favor, indique su contrase�a:");
		String password = sc.nextLine();
		System.out.println("Saldo: 0 ");
		int saldo = 0;
		System.out.println("Por favor, indique su correo:");
		String correo = sc.nextLine();
		agregarCliente(nombre,password,saldo,correo);
		listaClientes.setCont(listaClientes.getCont()+1);
	}
	/**
	 * Opens admin menu, offering admin-exclusive options
	 */
	public static void menu_admin() {
		boolean llave =true;
		while(llave) {
			System.out.println("MEN� ADMIN: ");
			System.out.println("1) Bloquear usuario");
			System.out.println("2) Ver historial de compras");
			System.out.println("3) Agregar producto");
			System.out.println("4) Agregar stock");
			System.out.println("5) Actualizar datos");
			System.out.println("6) Salir");
			sc = new Scanner(System.in);
			String seleccion = sc.nextLine();
			if((seleccion).equals("1")) {
				bloquear_Usuario();
			}
			else if((seleccion).equals("2")) {
				ver_Historial();
			}
			else if((seleccion).equals("3")) {
				agregar_Producto();
			}
			else if((seleccion).equals("4")) {
				agregar_Stock();
			}
			else if((seleccion).equals("5")) {
				actualizar_Datos();
			}
			else if((seleccion).equals("6")) {
				llave=false;
				System.out.println("Saliendo");
			}
			else {
				System.out.println("ERROR-NO SE RECONOCE EL COMANDO");
			}
		}
	}
	/**
	 * Disables a client's access to menu
	 */
	public static void bloquear_Usuario() {
		System.out.println("Bloquear usuario");
		sc = new Scanner(System.in);
		System.out.println("Nombre del cliente:");
		String nombre = sc.nextLine();
		Cliente bloquear = listaClientes.buscarNombre(nombre);
		int posicion = listaClientes.posicionCliente(nombre);
		listaClientes.eliminarCliente(bloquear, posicion);
	}
	/**
	 * Shows sold products and how many times they have been sold
	 */
	public static void ver_Historial() {
		for(int i=0;i<listaVentas.getCont();i++) {
			System.out.println("Nombre: "+listaVentas.getVentaI(i).getNombre());
			System.out.println("N�Ventas: "+listaVentas.getVentaI(i).getCantidadVentas());
			System.out.println("--------------------");
		}
	}
	/**
	 * Adds a product to the list
	 */
	public static void agregar_Producto() {
		sc = new Scanner(System.in);
		System.out.println("Ingrese el nombre del producto: ");
		String nombre = sc.nextLine();
		if (nombre.equals("")) {
			System.out.println("No se ha ingresado ning�n producto");
		}
		else if (!verificarExistenciaProducto(nombre)) {
			System.out.println("Ingrese el precio del producto: ");
			int precio = sc.nextInt();
			System.out.println("Ingrese el stock inicial del producto: ");
			int stockI = sc.nextInt();
			agregarProducto(nombre,precio,stockI);
		}
		else {
			System.out.println("El producto ya existe");
		}
	}
	/**
	 * Increases a product's stock
	 */
	public static void agregar_Stock() {
		sc = new Scanner(System.in);
		System.out.println("Ingrese el nombre del producto: ");
		String nombre = sc.nextLine();
		if (verificarExistenciaProducto(nombre)) {
			System.out.println("Ingrese el stock que desea agregar: ");
			int stockA = sc.nextInt();
			Producto p = listaProductos.buscarProducto(nombre);
			int unidadesInicial = p.getUnidades();
			unidadesInicial+=stockA;
			p.setUnidades(unidadesInicial);
		}
		else {
			System.out.println("El producto no existe");
		}
	}
	/**
	 * Changes the price of an already existing product
	 */
	public static void actualizar_Datos() {
		sc = new Scanner(System.in);
		System.out.println("Ingrese el nombre del producto:");
		String nombre = sc.nextLine();
		if (verificarExistenciaProducto(nombre)) {
			System.out.println("Ingrese el nuevo precio:");
			int precioNuevo= sc.nextInt();
			Producto p = listaProductos.buscarProducto(nombre);
			 p.setPrecio(precioNuevo);
		}
		else {
			System.out.println("El producto no existe");
		}
	}
	/**
	 * Opens client menu, offering options to the client
	 */
	public static void menu_cliente() {
		boolean llave1 =true;
		while(llave1) {
			System.out.println("MEN� CLIENTE");
			System.out.println("------------");
			System.out.println("1) Elegir producto");
			System.out.println("2) Cambio de contrase�a");
			System.out.println("3) Ver cat�logo");
			System.out.println("4) Ver saldo");
			System.out.println("5) Recargar saldo");
			System.out.println("6) Ver carro");
			System.out.println("7) Quitar del carro");
			System.out.println("8) Pagar carro");
			System.out.println("9) Salir");
			sc = new Scanner(System.in);
			String seleccion = sc.nextLine();
			if((seleccion).equals("1")) {
				System.out.println("Elegir producto");
				elegir_Producto();
			}
			else if((seleccion).equals("2")) {
				System.out.println("Cambio de contrase�a");
				cambio_Contrase�a();
			}
			if((seleccion).equals("3")) {
				System.out.println("Ver cat�logo");
				ver_Catalogo();
			}
			else if((seleccion).equals("4")) {
				System.out.println("Ver saldo");
				ver_Saldo();
			}
			if((seleccion).equals("5")) {
				System.out.println("Recargar saldo");
				recarga_Saldo();
			}
			else if((seleccion).equals("6")) {
				System.out.println("Ver carro");
				ver_Carro();
			}
			else if((seleccion).equals("7")) {
				System.out.println("Quitar del carro");
				quitar_Carro();
			}
			else if((seleccion).equals("8")) {
				System.out.println("Pagar carro");
				pagar_Carro();
			}
			else if((seleccion).equals("9")) {
				llave1 = false;
				System.out.println("Saliendo");
			}
			else {
				System.out.println("ERROR-NO SE RECONOCE EL COMANDO");
			}
		}
	}
	/**
	 * Adds a product to the cart
	 */
	public static void elegir_Producto() {
		sc = new Scanner(System.in);
		System.out.println("Ingrese el nombre del producto: ");
		String nombre = sc.nextLine();
		int i = cont;
		if (verificarExistenciaProducto(nombre)) {
			int posicion = listaProductos.posicionProducto(nombre);
			int unidades = listaProductos.getProductoI(posicion).getUnidades();
			if(unidades > 0) {
				System.out.println("Ingrese cantidad a comprar: ");
				int cantCompra = sc.nextInt();
				if(cantCompra <= unidades) {
					nombreCompras[i] = nombre;
					cantCompras[i] = cantCompra;
					cont++;
					totalPago+=listaProductos.getProductoI(posicion).getPrecio()*cantCompra;
					int nuevoStock = unidades-cantCompra;
					listaProductos.getProductoI(posicion).setUnidades(nuevoStock);
				}
				else {
					System.out.println("La cantidad deseada sobrepasa al stock actual");
				}
			}
			else {
				System.out.println("No hay stock");
			}
		}
		else {
			System.out.println("El producto no existe");
		}
	}
	/**
	 * Changes the client's password for a longer one
	 */
	public static void cambio_Contrase�a() {
		sc = new Scanner(System.in);
		String nombreC = clienteActual;
		Cliente c = listaClientes.buscarNombre(nombreC);
		if(c != null) {
			if (nombreC.equals(c.getNombre())){
				System.out.println("Ingrese la contrase�a antigua: ");
				String contrase�aAntigua = sc.nextLine();
				if(contrase�aAntigua.equals(c.getContrase�a())) {
					int tama�oAnterior = c.getContrase�a().length();
					System.out.println("La contrase�a es correcta");
					System.out.println("Ingrese la contrase�a nueva: ");
					String contrase�aNueva = sc.nextLine();
					int tama�oNuevo = contrase�aNueva.length();
					if(tama�oNuevo>=tama�oAnterior) {
						System.out.println("Su contrase�a se ha cambiado con exito");
						c.setContrase�a(contrase�aNueva);
					}
				}
				else {
					System.out.println("La contrase�a es incorrecta");	
					}
			}
			else {
				System.out.println("No se ha encontrado al cliente");
				}
		}
		else {
			System.out.println("Volviendo al principio...");
		}
	}
	/**
	 * Shows the products list
	 */
	public static void ver_Catalogo() {
		for(int i=0;i<listaProductos.getCont();i++) {
			int stock = listaProductos.getProductoI(i).getUnidades();
			if (stock > 0) {
			System.out.println("Nombre: "+listaProductos.getProductoI(i).getNombre());
			System.out.println("Stock: "+listaProductos.getProductoI(i).getUnidades());
			}
			else {
				System.out.println("No hay stock de "+listaProductos.getProductoI(i).getNombre());
			}
		}
	}
	/**
	 * Shows client's balance
	 */
	public static void ver_Saldo() {
		sc = new Scanner(System.in);
		String nombreC = clienteActual;
		Cliente c = listaClientes.buscarNombre(nombreC);
		if(c != null) {
			if (nombreC.equals(c.getNombre())){
				int posicionCliente = listaClientes.posicionCliente(nombreC);
				System.out.println("Su saldo es de: "+listaClientes.getClienteI(posicionCliente).getSaldo());
			}
			else {
				System.out.println("No se ha encontrado al cliente");
			}
		}
		else {
			System.out.println("Volviendo al principio...");
		}
	}
	/**
	 * Increases client's balance
	 */
	public static void recarga_Saldo() {
		sc = new Scanner(System.in);
		String nombreC = clienteActual;
		Cliente c = listaClientes.buscarNombre(nombreC);
		if(c != null) {
			if (nombreC.equals(c.getNombre())){
				int posicionCliente = listaClientes.posicionCliente(nombreC);
				int saldo = listaClientes.getClienteI(posicionCliente).getSaldo();
				System.out.println("Ingrese el saldo a recargar:");
				int recarga = sc.nextInt();
				saldo+=recarga;
				listaClientes.getClienteI(posicionCliente).setSaldo(saldo);
			}
			else {
				System.out.println("No se ha encontrado al cliente");
			}
		}
		else {
			System.out.println("Volviendo al principio...");
		}
	}
	/**
	 * Shows in-cart products
	 */
	public static void ver_Carro() {
		for(int i=0;i<cont;i++) {
			String nomProducto = nombreCompras[i];
			int cantProducto = cantCompras[i];
			int posicion = listaProductos.posicionProducto(nomProducto);
			int precio = listaProductos.getProductoI(posicion).getPrecio();
			System.out.println("Nombre: "+nomProducto+" Cantidad: "+cantProducto+" Precio: "+ precio);
			System.out.println("-----------------------------------------------------------");
		}
	}
	/**
	 * Takes a product out of the cart
	 */
	public static void quitar_Carro() {
		sc = new Scanner(System.in);
		System.out.println("Ingrese el nombre del producto a eliminar: ");
		String nombre = sc.nextLine();
		for(int i = 0;i<cont;i++) {
			if(nombre.equals(nombreCompras[i])) {
				nombreCompras[i] = "";
				cantCompras[i] = 0;
				cont--;
			}
			else {
				System.out.println("El producto que desea eliminar no se encuentra");
			}
		}
	}
	/**
	 * Shows the total price of the products in cart and asks the client to pay for them
	 */
	public static void pagar_Carro() {
		sc = new Scanner(System.in);
		String nombreC = clienteActual;
		int posicion = listaClientes.posicionCliente(nombreC);
		System.out.println("Total a pagar: "+totalPago);
		System.out.println("�Desea hacer el pago? S� (1)- NO (2): ");
		String opcionPago = sc.nextLine();
		if(opcionPago.equals("1")) {
			System.out.println("Realizando el pago...");
			agregar_Venta();
			vaciar_Carros();
			int saldoCompra = listaClientes.getClienteI(posicion).getSaldo()-totalPago;
			listaClientes.getClienteI(posicion).setSaldo(saldoCompra);
			totalPago = 0;
			clienteActual = "";
		}
		else {
			System.out.println("Volviendo al principio...");
		}
	}
	/**
	 * Empties the cart
	 */
	public static void vaciar_Carros() {
		for(int i = 0;i<cont;i++) {
			nombreCompras[i] = nombreCompras[i+1];
			cantCompras[i] = cantCompras[i+1];
		}
		cont=0;
	}
	/**
	 * Registers the sale in the list
	 */
	public static void agregar_Venta() {
		for(int i = 0; i<cont;i++) {
			String nombreProducto = nombreCompras[i];
			int cantProducto = cantCompras[i];
			int posicion = listaProductos.posicionProducto(nombreProducto);
			if(verificarExistenciaVenta(nombreProducto)){
				int cantVentas = listaProductos.getProductoI(posicion).getUnidades()+cantProducto;
				listaProductos.getProductoI(posicion).setUnidades(cantVentas);
			}
			else if(!verificarExistenciaVenta(nombreProducto)) {
				agregarVenta(nombreProducto,cantProducto);
			}
		}
	}
	/**
	 * Checks if a product exists in the list
	 * @param nombreP
	 * Wanted product name
	 * @return
	 */
	public static boolean verificarExistenciaProducto(String nombreP) {
		Producto nuevo = listaProductos.buscarProducto(nombreP);
		if(nuevo==null) {
			return false;
		}
		else {
			return true;
		}
	}
	/**
	 * Checks if a client exists in the list
	 * @param nombreC
	 * Wanted client's name
	 * @return
	 */
	public static boolean verificarExistenciaCliente(String nombreC) {
		Cliente nuevo = listaClientes.buscarNombre(nombreC);
		if(nuevo==null) {
			return false;
		}
		else {
			return true;
		}
	}
	/**
	 * Checks if a sale exists in the list
	 * @param nombreV
	 * Wanted sale product name
	 * @return
	 */
	public static boolean verificarExistenciaVenta(String nombreV) {
		Venta nuevo = listaVentas.buscarNombre(nombreV);
		if(nuevo==null) {
			return false;
		}
		else {
			return true;
		}
	}
	/**
	 * Creates a string with every client's names, passwords, balance and e-mail addresses
	 * @return
	 */
	public static String StringClientes() {
		String salida = "";
		for(int i=0;i<listaClientes.getCont();i++) {
			salida += listaClientes.getClienteI(i).getNombre()+","+listaClientes.getClienteI(i).getContrase�a()+","+listaClientes.getClienteI(i).getSaldo()+","+listaClientes.getClienteI(i).getCorreo()+"\n";	
		}
		return salida.trim();
	}
	/**
	 * Creates a string with every product name, price and stock
	 * @return
	 */
	public static String StringProductos() {
		String salida = "";
		for(int i=0;i<listaProductos.getCont();i++) {
			salida += listaProductos.getProductoI(i).getNombre()+", "+listaProductos.getProductoI(i).getPrecio()+", "+listaProductos.getProductoI(i).getUnidades()+"\n";	
		}
		return salida.trim();
	}
	/**
	 * Creates a string with every sold product name and stock
	 * @return
	 */
	public static String StringVentas() {
		String salida = "";
		for(int i=0;i<listaVentas.getCont();i++) {
			salida += listaVentas.getVentaI(i).getNombre()+","+listaVentas.getVentaI(i).getCantidadVentas()+"\n";	
		}
		return salida.trim();
	}
	/**
	 * Saves the clients data in the "Clientes.txt" file
	 * @throws IOException
	 */
	public static void Guardar_Clientes() throws IOException {
		FileWriter fw = new FileWriter("Clientes.txt");
		fw.write(StringClientes());
        fw.close();
	}
	/**
	 * Saves the products data in the "Productos.txt" file
	 * @throws IOException
	 */
	public static void Guardar_Productos() throws IOException {
		FileWriter fw = new FileWriter("Productos.txt");
		fw.write(StringProductos());
        fw.close();
	}
	/**
	 * Saves the sales data in the "Ventas.txt" file
	 * @throws IOException
	 */
	public static void Guardar_Ventas() throws IOException {
		FileWriter fw = new FileWriter("Ventas.txt");
		fw.write(StringVentas());
        fw.close();
	}

}
