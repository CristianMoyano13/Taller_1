package L�gica;

import Dominio.Venta;

public class ListaVentas {
	private Venta[] listaVentas;
	private int cont;
	private int max;
	/**
	 * List of sales
	 * @param max
	 * Maximum of sales the list can store
	 */
	public ListaVentas(int max) {
		listaVentas = new Venta[max];
		cont = 0;
		this.max=max;
	}
	/**
	 * Adds a sale to the list
	 * @param venta
	 * Sale to be added to the list
	 * @return
	 */
	public boolean insertarVenta(Venta venta) { 
		if (cont < max) {
			listaVentas[cont] = venta;
			cont++;
			return true;

		} else {
			return false;
		}
	}
	/**
	 * Searches for a sale index by its product name if exists
	 * @param nombre
	 * Wanted sale product name
	 * @return
	 */
	public int posicionVenta(String nombre) {
        for (int i = 0; i <= cont; i++) {
            if (listaVentas[i].equals(nombre)) {
                return i;
            }
        }
		return -1;
	}
	/**
	 * Searches for a sale by its product name if exists
	 * @param nombreProducto
	 * Wanted sale product name
	 * @return
	 */
	public Venta buscarNombre(String nombreProducto) {
		int i;
		for (i = 0; i < cont; i++) {
			if (listaVentas[i].getNombre().equals(nombreProducto)) {
				break;
			}
		}
		if (i == cont) {
			return null;
		} 
		else {
			return listaVentas[i];
		}
	}
	/**
	 * Searches for a sale by its index if exists
	 * @param i
	 * Wanted sale index
	 * @return
	 */
	public Venta getVentaI(int i) {
		if (i >= 0 && i < cont) {
			return listaVentas[i];

		} else {
			return null;
		}
	}
	/**
	 * Returns the sales list
	 * @return
	 */
	public Venta[] getListaVentas() {
		return listaVentas;
	}
	/**
	 * Sets a new sales list
	 * @param listaVentas
	 * New sales list
	 */
	public void setListaVentas(Venta[] listaVentas) {
		this.listaVentas = listaVentas;
	}
	/**
	 * Returns the value of the sales counter
	 * @return
	 */
	public int getCont() {
		return cont;
	}
	/**
	 * Sets a new value for the sales counter
	 * @param cont
	 * New value for the sales counter
	 */
	public void setCont(int cont) {
		this.cont = cont;
	}
}
