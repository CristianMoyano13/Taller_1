package L�gica;

import Dominio.Cliente;

public class ListaClientes {
	private Cliente[] listaClientes;
	private int cont;
	private int max;
	/**
	 * List of clients
	 * @param max
	 * Maximum of clients the list can store
	 */
	public ListaClientes(int max) {
		listaClientes = new Cliente[max];
		cont = 0;
		this.max=max;
	}
	/**
	 * Searches for a client index in the list if exists
	 * @param nombre
	 * Wanted client's name
	 * @return
	 */
	public int posicionCliente(String nombre) {
        for (int i = 0; i <= cont; i++) {
            if (listaClientes[i].getNombre().equals(nombre)) {
                return i;
            }
        }
		return -1;
	}
	/**
	 * Adds a client to the list
	 * @param cliente
	 * Client to be added to the list
	 * @return
	 */
	public boolean insertarCliente(Cliente cliente) { 
		if (cont < max) {
			listaClientes[cont] = cliente;
			cont++;
			return true;

		} else {
			return false;
		}
	}
	/**
	 * Removes a client from the list
	 * @param cliente
	 * Client
	 * @param posicionCliente
	 * Index of the client to be removed
	 * @return
	 */
	public boolean eliminarCliente(Cliente cliente, int posicionCliente) { 
		if (cont < max) {
			for(int i=posicionCliente;i<cont;i++) {
				listaClientes[posicionCliente] = listaClientes[i+1];
			}
			return true;
		} else {
			return false;
		}
	}
	/**
	 * Searches for a client's index by its name if exists
	 * @param nombre
	 * Wanted client's name
	 * @return
	 */
	public Cliente buscarNombre(String nombre) {
		int i;
		for (i = 0; i < cont; i++) {
			if (listaClientes[i].getNombre().equals(nombre)) {
				break;
			}
		}
		if (i == cont) {
			return null;
		} 
		else {
			return listaClientes[i];
		}
	}
	/**
	 * Searches for a client by its index if exists
	 * @param i
	 * Wanted client's index
	 * @return
	 */
	public Cliente getClienteI(int i) {
		if (i >= 0 && i < cont) {
			return listaClientes[i];

		} else {
			return null;
		}
	}
	/**
	 * Returns the client list
	 * @return
	 */
	public Cliente[] getListaClientes() {
		return listaClientes;
	}
	/**
	 * Sets a new client list
	 * @param listaClientes
	 * New client list
	 */
	public void setListaClientes(Cliente[] listaClientes) {
		this.listaClientes = listaClientes;
	}
	/**
	 * Returns the value of the client counter
	 * @return
	 */
	public int getCont() {
		return cont;
	}
	/**
	 * Sets a new value for the client counter
	 * @param cont
	 * New value for the client counter
	 */
	public void setCont(int cont) {
		this.cont = cont;
	}
	/**
	 * Returns the clients maximum
	 * @return
	 */
	public int getMax() {
		return max;
	}
	/**
	 * Sets a new clients maximum
	 * @param max
	 * New clients maximum
	 */
	public void setMax(int max) {
		this.max = max;
	}
}
