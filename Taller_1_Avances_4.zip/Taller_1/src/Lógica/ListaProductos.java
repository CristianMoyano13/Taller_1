package L�gica;


import Dominio.Producto;

public class ListaProductos {
	private Producto[] listaProductos;
	private int cont;
	private int max;
	/**
	 * List of products
	 * @param max
	 * Maximum of products the list can store
	 */
	public ListaProductos(int max) {
		listaProductos = new Producto[max];
		cont = 0;
		this.max=max;
	}
	/**
	 * Adds a product to the list
	 * @param producto
	 * Product to be added to the list
	 * @return
	 */
	public boolean insertarProducto(Producto producto) { 
		if (cont < max) {
			listaProductos[cont] = producto;
			cont++;
			return true;

		} else {
			return false;
		}
	}
	/**
	 * Searches for a product by its name if exists
	 * @param nombreProducto
	 * Wanted product name
	 * @return
	 */
	public Producto buscarProducto(String nombreProducto) {
		int i;
		for (i = 0; i < cont; i++) {
			if ((listaProductos[i].getNombre()).equals(nombreProducto)) {
				break;
			}
		}
		if (i == cont) {
			return null;
		} 
		else {
			return listaProductos[i];
		}
	}
	/**
	 * Searches for a product index by its name if exists
	 * @param nombre
	 * Wanted product name
	 * @return
	 */
	public int posicionProducto(String nombre) {
        for (int i = 0; i <= cont; i++) {
            if ((listaProductos[i].getNombre()).equals(nombre)) {
                return i;
            }
        }
		return -1;
	}
	/**
	 * Searches for a product by its index if exists
	 * @param i
	 * Wanted product index
	 * @return
	 */
	public Producto getProductoI(int i) {
		if (i >= 0 && i < cont) {
			return listaProductos[i];

		} else {
			return null;
		}
	}
	/**
	 * Returns the products list
	 * @return
	 */
	public Producto[] getListaProductos() {
		return listaProductos;
	}
	/**
	 * Sets a new products list
	 * @param listaProductos
	 * New products list
	 */
	public void setListaProductos(Producto[] listaProductos) {
		this.listaProductos = listaProductos;
	}
	/**
	 * Returns the value of the product counter
	 * @return
	 */
	public int getCont() {
		return cont;
	}
	/**
	 * Sets a new value for the product counter
	 * @param cont
	 * New value for the product counter
	 */
	public void setCont(int cont) {
		this.cont = cont;
	}
}
